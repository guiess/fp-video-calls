import express from "express";
import http from "http";
import https from "https";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { Server as SocketIOServer } from "socket.io";
import crypto from "crypto";
import cors from "cors";
import admin from "firebase-admin";

// ── Firebase Admin (optional — only initialised when service account is set) ──
// Set FIREBASE_SERVICE_ACCOUNT_JSON to a base64-encoded service-account JSON,
// or GOOGLE_APPLICATION_CREDENTIALS to the path of the JSON file.
let firebaseReady = false;
try {
  const saJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON;
  if (saJson) {
    const credential = admin.credential.cert(
      JSON.parse(Buffer.from(saJson, "base64").toString("utf8"))
    );
    admin.initializeApp({ credential });
    firebaseReady = true;
    console.log("[firebase] Admin SDK initialised");
  } else if (process.env.GOOGLE_APPLICATION_CREDENTIALS) {
    admin.initializeApp({ credential: admin.credential.applicationDefault() });
    firebaseReady = true;
    console.log("[firebase] Admin SDK initialised via GOOGLE_APPLICATION_CREDENTIALS");
  } else {
    console.log("[firebase] No service account configured — call invite endpoints disabled");
  }
} catch (e) {
  console.error("[firebase] Admin SDK init failed:", e);
}

const app = express();
app.set("trust proxy", 1);
// Dev/Prod CORS: allowlist via env, fallback to permissive during dev
const allowlist = (process.env.CORS_ORIGINS || process.env.CORS_ORIGIN || "")
  .split(",")
  .map(s => s.trim())
  .filter(Boolean);
const allowCredentials = (process.env.CORS_CREDENTIALS || "false").toLowerCase() === "true";
const corsOptions = {
  origin: (origin, cb) => {
    if (!origin) return cb(null, true);
    if (allowlist.length === 0) return cb(null, true);
    cb(null, allowlist.includes(origin));
  },
  methods: ["GET", "POST", "DELETE", "OPTIONS"],
  credentials: allowCredentials
};
app.use(cors(corsOptions));
app.options("*", cors(corsOptions));

// Additional CORS headers to satisfy strict browsers over HTTPS
app.use((req, res, next) => {
  const origin = req.headers.origin;
  const allowed =
    !origin
      ? false
      : allowlist.length === 0
      ? true
      : allowlist.includes(origin);

  // Echo allowed origin or fallback to "*"
  if (allowed && origin) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  } else {
    res.setHeader("Access-Control-Allow-Origin", "*");
  }

  res.setHeader("Access-Control-Allow-Methods", "GET,POST,DELETE,OPTIONS");
  const allowHeaders = process.env.CORS_ALLOW_HEADERS || "Content-Type, Authorization";
  res.setHeader("Access-Control-Allow-Headers", allowHeaders);
  res.setHeader("Access-Control-Max-Age", "86400");

  if (allowCredentials) {
    res.setHeader("Access-Control-Allow-Credentials", "true");
  }

  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
});

app.use(express.json());
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const certDir = path.resolve(__dirname, "../web/certs");
const keyPath = path.join(certDir, "dev.key");
const crtPath = path.join(certDir, "dev.crt");

// Use HTTPS if dev certs exist to avoid mixed content when the web app runs on https.
const useHttps = fs.existsSync(keyPath) && fs.existsSync(crtPath);
const server = useHttps
  ? https.createServer({ key: fs.readFileSync(keyPath), cert: fs.readFileSync(crtPath) }, app)
  : http.createServer(app);

const io = new SocketIOServer(server, {
  cors: {
    origin: (origin, cb) => {
      if (!origin) return cb(null, true);
      if (allowlist.length === 0) return cb(null, true);
      cb(null, allowlist.includes(origin));
    },
    methods: ["GET", "POST", "DELETE", "OPTIONS"],
    credentials: allowCredentials
  },
  transports: ["websocket", "polling"]
});

// In-memory rooms for local testing (no persistence)
// roomId -> { participants: Map(userId -> { socketId, displayName }), settings: { videoQuality, passwordEnabled, passwordHash?, passwordHint? } }
const rooms = new Map();
// participants info extended: { socketId, displayName, micMuted?: boolean }

// Health
app.get("/health", (_req, res) => res.json({ ok: true, ts: Date.now() }));
// Simple endpoint to verify CORS from other devices
app.get("/cors-check", (_req, res) => res.json({ ok: true, origin: _req.headers.origin ?? null }));

// TURN (coturn REST auth) ephemeral credentials
const TURN_TTL_SECONDS = parseInt(process.env.TURN_TTL_SECONDS || "300", 10);
const TURN_SECRET = (process.env.TURN_HMAC_SECRET || "").trim();
const TURN_REALM = (process.env.TURN_REALM || process.env.TURN_DOMAIN || "").trim();
const TURN_URLS = (process.env.TURN_URLS || "").split(",").map(s => s.trim()).filter(Boolean);

function issueTurnCredentials(userId, roomId, realm, urls) {
  const ts = Math.floor(Date.now() / 1000) + TURN_TTL_SECONDS;
  const username = `${userId}:${ts}`;
  const hmac = crypto.createHmac("sha1", TURN_SECRET);
  hmac.update(username);
  const credential = hmac.digest("base64");
  return { username, credential, ttl: TURN_TTL_SECONDS, urls, realm, roomId, userId };
}

// GET /api/turn?userId=...&roomId=...
app.get("/api/turn", (req, res) => {
  try {
    const userId = String(req.query.userId || "").trim();
    const roomId = String(req.query.roomId || "").trim();
    if (!TURN_SECRET || TURN_SECRET.length < 8) {
      return res.status(500).json({ ok: false, error: "TURN_SECRET_NOT_CONFIGURED" });
    }
    if (!TURN_REALM) {
      return res.status(500).json({ ok: false, error: "TURN_REALM_NOT_CONFIGURED" });
    }
    const urls = TURN_URLS.length ? TURN_URLS : [
      `turns:turn.${TURN_REALM}:5349?transport=udp`,
      `turns:turn.${TURN_REALM}:5349?transport=tcp`,
      `turn:turn.${TURN_REALM}:3478?transport=udp`,
      `turn:turn.${TURN_REALM}:3478?transport=tcp`
    ];
    if (!userId) return res.status(400).json({ ok: false, error: "BAD_REQUEST", hint: "userId required" });
    // Optional: room existence check for basic scoping
    const room = rooms.get(roomId);
    if (roomId && !room) {
      // Not fatal; allow issuance for pre-join flows, but you can require room existence by uncommenting:
      // return res.status(404).json({ ok: false, error: "ROOM_NOT_FOUND" });
    }
    const payload = issueTurnCredentials(userId, roomId || null, TURN_REALM, urls);
    return res.json(payload);
  } catch (e) {
    console.error("[turn] issue failed", e);
    return res.status(500).json({ ok: false, error: "TURN_ISSUE_FAILED" });
  }
});

// ── Mobile call invite / cancel (Firebase FCM) ────────────────────────────

/** Lookup a user's FCM token from Firestore */
async function getFcmToken(uid) {
  const doc = await admin.firestore().collection("users").doc(uid).get();
  return doc.exists ? (doc.data().fcmToken || null) : null;
}

/**
 * POST /api/call/invite
 * Body: { callerId, callerName, callerPhoto?, calleeUids: string[], roomId, callType }
 * Sends an FCM data message to each callee so their device rings.
 */
app.post("/api/call/invite", async (req, res) => {
  if (!firebaseReady) {
    return res.status(503).json({ ok: false, error: "FIREBASE_NOT_CONFIGURED" });
  }
  const { callerId, callerName, callerPhoto, calleeUids, roomId, callType, roomPassword } = req.body || {};
  if (!callerId || !callerName || !Array.isArray(calleeUids) || calleeUids.length === 0 || !roomId) {
    return res.status(400).json({ ok: false, error: "BAD_REQUEST" });
  }
  const callUUID = crypto.randomUUID();
  try {
    const results = await Promise.allSettled(
      calleeUids.map(async (uid) => {
        const token = await getFcmToken(uid);
        if (!token) return;
        await admin.messaging().send({
          token,
          notification: {
            title: "Incoming Call",
            body: `${String(callerName)} is calling you`,
          },
          android: {
            priority: "high",
            notification: {
              channelId: "calls",
              priority: "max",
              defaultSound: false,
              defaultVibrateTimings: false,
              vibrateTimingsMillis: [0, 1000, 500, 1000],
            },
          },
          data: {
            type: "call_invite",
            callUUID,
            callerId: String(callerId),
            callerName: String(callerName),
            callerPhoto: String(callerPhoto || ""),
            calleeUid: String(uid),
            roomId: String(roomId),
            callType: String(callType || "direct"),
            roomPassword: String(roomPassword || ""),
          },
        });
      })
    );
    const failed = results.filter(r => r.status === "rejected").length;
    return res.json({ ok: true, callUUID, sent: calleeUids.length - failed, failed });
  } catch (e) {
    console.error("[call/invite] failed", e);
    return res.status(500).json({ ok: false, error: "SEND_FAILED" });
  }
});

/**
 * POST /api/call/cancel
 * Body: { calleeUids: string[], roomId }
 * Sends a cancel FCM message so the callee's ringing screen dismisses.
 */
app.post("/api/call/cancel", async (req, res) => {
  if (!firebaseReady) {
    return res.status(503).json({ ok: false, error: "FIREBASE_NOT_CONFIGURED" });
  }
  const { calleeUids, roomId, callUUID } = req.body || {};
  if (!Array.isArray(calleeUids) || calleeUids.length === 0 || !roomId) {
    return res.status(400).json({ ok: false, error: "BAD_REQUEST" });
  }
  try {
    await Promise.allSettled(
      calleeUids.map(async (uid) => {
        const token = await getFcmToken(uid);
        if (!token) return;
        await admin.messaging().send({
          token,
          android: { priority: "high" },
          data: { type: "call_cancel", roomId: String(roomId), callUUID: String(callUUID || "") },
        });
      })
    );
    return res.json({ ok: true });
  } catch (e) {
    console.error("[call/cancel] failed", e);
    return res.status(500).json({ ok: false, error: "SEND_FAILED" });
  }
});

// Create room (returns human-readable slug). Password can only be set at creation.
app.post("/room", (req, res) => {
  const { videoQuality = "720p", passwordEnabled = false, passwordHint, password } = req.body || {};
  const roomId = generateSlug();
  rooms.set(roomId, {
    participants: new Map(),
    settings: {
      videoQuality: videoQuality === "1080p" ? "1080p" : "720p",
      passwordEnabled: !!passwordEnabled,
      passwordHash: passwordEnabled && password ? hashPassword(password) : undefined,
      passwordHint: passwordHint
    }
  });
  res.status(201).json({ roomId, settings: rooms.get(roomId).settings });
});

// Room meta (for password/quality)
app.get("/room/:roomId/meta", (req, res) => {
  const { roomId } = req.params;
  const room = rooms.get(roomId);
  res.json({
    roomId,
    exists: !!room,
    settings: room?.settings || {
      videoQuality: "720p",
      passwordEnabled: false
    }
  });
});

io.on("connection", (socket) => {
  // join_room { roomId, userId, displayName, password?, videoQuality? }
  socket.on("join_room", ({ roomId, userId, displayName, password, videoQuality }) => {
    if (!roomId || !userId) return socket.emit("error", { code: "BAD_REQUEST" });

    // Normalize requested quality defensively
    const reqQ = typeof videoQuality === "string" ? videoQuality.trim().toLowerCase() : "";
    const normalizedQ = reqQ === "1080p" ? "1080p" : reqQ === "720p" ? "720p" : null;

    // Auto-create room on first join if not present (no password by default)
    if (!rooms.has(roomId)) {
      const q = normalizedQ ?? "720p";
      rooms.set(roomId, {
        participants: new Map(),
        settings: { videoQuality: q, passwordEnabled: false }
      });
      console.log(`[room:create] ${roomId} quality=${q} (requested=${videoQuality})`);
    }

    const room = rooms.get(roomId);
    // Password verification if enabled at creation
    if (room.settings.passwordEnabled) {
      if (!password || password.length < 1) {
        return socket.emit("error", { code: "AUTH_REQUIRED", hint: room.settings.passwordHint });
      }
      if (!verifyPassword(password, room.settings.passwordHash)) {
        return socket.emit("error", { code: "AUTH_FAILED" });
      }
    }

    const isReconnect = room.participants.has(userId);
    const prevMicMuted = isReconnect ? !!room.participants.get(userId)?.micMuted : false;
    room.participants.set(userId, { socketId: socket.id, displayName, micMuted: prevMicMuted });
    socket.join(roomId);

    // Notify caller with existing participants (include micMuted for initial badges)
    const participants = Array.from(room.participants.entries()).map(([id, p]) => ({
      userId: id,
      displayName: p.displayName,
      micMuted: !!p.micMuted
    }));
    socket.emit("room_joined", { participants, roomInfo: { roomId, settings: room.settings } });

    // Only notify others on first join (skip for reconnects to avoid duplicate user_joined)
    if (!isReconnect) {
      socket.to(roomId).emit("user_joined", { userId, displayName, micMuted: false });
    } else {
      console.log(`[room:rejoin] ${userId} reconnected to ${roomId}`);
    }
  });

  socket.on("leave_room", ({ roomId, userId }) => {
    const room = rooms.get(roomId);
    if (room) {
      room.participants.delete(userId);
      socket.leave(roomId);
      socket.to(roomId).emit("user_left", { userId });
      if (room.participants.size === 0) rooms.delete(roomId);
    }
  });

  // Admin: close room for everybody
  socket.on("close_room", ({ roomId }) => {
    const room = rooms.get(roomId);
    if (!room) return;
    // Inform all clients and remove them
    io.to(roomId).emit("error", { code: "ROOM_CLOSED", message: "Room was closed by host" });
    for (const [uid, info] of room.participants.entries()) {
      try { io.sockets.sockets.get(info.socketId)?.leave(roomId); } catch {}
      socket.to(roomId).emit("user_left", { userId: uid });
    }
    rooms.delete(roomId);
    console.log(`[room:close] ${roomId}`);
  });

  // WebRTC signaling relay
  socket.on("offer", ({ roomId, targetId, offer }) => {
    relayToUser(roomId, targetId, "offer_received", { fromId: getUserIdBySocket(roomId, socket.id), offer });
  });
  socket.on("answer", ({ roomId, targetId, answer }) => {
    relayToUser(roomId, targetId, "answer_received", { fromId: getUserIdBySocket(roomId, socket.id), answer });
  });
  socket.on("ice_candidate", ({ roomId, targetId, candidate }) => {
    relayToUser(roomId, targetId, "ice_candidate_received", { fromId: getUserIdBySocket(roomId, socket.id), candidate });
  });

  // Simple room chat channel
  socket.on("chat_message", ({ roomId, userId, displayName, text, ts }) => {
    const room = rooms.get(roomId);
    if (!room) return;
    const safeText = typeof text === "string" ? text.slice(0, 2000) : "";
    const name = displayName || (room.participants.get(userId)?.displayName ?? "Guest");
    io.to(roomId).emit("chat_message", { roomId, fromId: userId, displayName: name, text: safeText, ts: ts || Date.now() });
  });

  // Broadcast mic mute/unmute state to room participants
  socket.on("mic_state_changed", ({ roomId, userId, muted }) => {
    const room = rooms.get(roomId);
    if (!room) return;
    const p = room.participants.get(userId);
    if (p) {
      p.micMuted = !!muted;
      room.participants.set(userId, p);
    }
    io.to(roomId).emit("peer_mic_state", { userId, muted: !!muted });
  });

  socket.on("disconnect", () => {
    // Cleanup user from any rooms
    for (const [roomId, room] of rooms.entries()) {
      const userId = getUserIdBySocket(roomId, socket.id);
      if (userId) {
        room.participants.delete(userId);
        socket.to(roomId).emit("user_left", { userId });
        if (room.participants.size === 0) rooms.delete(roomId);
      }
    }
  });
});

// REST API: close room endpoint
app.post("/room/:roomId/close", (req, res) => {
  const { roomId } = req.params;
  const room = rooms.get(roomId);
  if (!room) return res.status(404).json({ ok: false, error: "NOT_FOUND" });
  io.to(roomId).emit("error", { code: "ROOM_CLOSED", message: "Room was closed by host" });
  for (const [uid, info] of room.participants.entries()) {
    try { io.sockets.sockets.get(info.socketId)?.leave(roomId); } catch {}
  }
  rooms.delete(roomId);
  console.log(`[room:close] ${roomId} via REST`);
  return res.json({ ok: true });
}
);

function getUserIdBySocket(roomId, socketId) {
  const room = rooms.get(roomId);
  if (!room) return null;
  for (const [uid, info] of room.participants.entries()) {
    if (info.socketId === socketId) return uid;
  }
  return null;
}

function relayToUser(roomId, targetUserId, event, payload) {
  const room = rooms.get(roomId);
  if (!room) return;
  const target = room.participants.get(targetUserId);
  if (!target) return;
  io.to(target.socketId).emit(event, payload);
}

// Simple human-readable slug generator
function generateSlug() {
  const adjectives = ["sunny", "brave", "calm", "bright", "happy", "quick", "sharp"];
  const nouns = ["mountain", "river", "forest", "sky", "ocean", "meadow", "valley"];
  const a = adjectives[Math.floor(Math.random() * adjectives.length)];
  const n = nouns[Math.floor(Math.random() * nouns.length)];
  const num = Math.floor(Math.random() * 90) + 10;
  return `${a}-${n}-${num}`;
}

// Very simple local hash/verify (not for production). Replace with bcrypt/argon2 in real app.
function hashPassword(pw) {
  return crypto.createHash("sha256").update(pw).digest("hex");
}
function verifyPassword(pw, hash) {
  return hashPassword(pw) === hash;
}

const PORT = process.env.PORT || 3000;
const HOST = process.env.HOST || "0.0.0.0";
server.listen(PORT, HOST, () => {
  const scheme = useHttps ? "https" : "http";
  console.log(`Signaling server listening on ${scheme}://${HOST}:${PORT}`);
  console.log(`Health: ${scheme}://${HOST}:${PORT}/health`);
  console.log(`Create room: POST ${scheme}://${HOST}:${PORT}/room (include passwordEnabled + password to protect)`);
  console.log(`TURN creds: GET ${scheme}://${HOST}:${PORT}/api/turn?userId=alice&roomId=room-123`);
  console.log(`Tip: from another device on LAN use ${scheme}://192.168.0.114:3000`);
});